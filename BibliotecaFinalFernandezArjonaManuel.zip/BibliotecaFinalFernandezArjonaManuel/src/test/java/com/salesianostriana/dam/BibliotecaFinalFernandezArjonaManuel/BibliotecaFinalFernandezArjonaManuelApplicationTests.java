package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaFinalFernandezArjonaManuelApplicationTests {

	@Test
	void contextLoads() {
	}

}
