package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.base;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

public abstract class BaseService<T, ID, R extends JpaRepository<T, ID>> {
	
	@Autowired
	protected R repository;
	
	/**
	 * Almacenamos una nueva entidad a través del repositorio
	 * @param t
	 * @return 
	 */
	public T save(T t) {
		return repository.save(t);
	}
	
	/**
	 * Localizamos una entidad en base a su Id.
	 * 
	 * 
	 * @param id
	 * @return la entidad si la encuentra o null si no lo encuentra
	 */
	public T findById(ID id) {
		return repository.findById(id).orElse(null);
	}
	
	/**
	 * Obtenemos todas las entidades de un tipo de entidad
	 * @return Todas las entidades
	 */
	public List<T> findAll() {
		return repository.findAll();
	}
	
	/**
	 * Editamos una instancia de una entidad (si no tiene Id, la insertamos).
	 * @param t
	 * @return
	 */
	public T edit(T t) {
		return repository.save(t);
	}
	
	/**
	 * Eliminamos una instancia de una entidad
	 * @param t
	 */
	public void delete(T t) {
		repository.delete(t);
	}
	
	/**
	 * Eliminamos una instancia en base a su ID
	 * @param id
	 */
	public void deleteById(ID id) {
		repository.deleteById(id);
	}

}
