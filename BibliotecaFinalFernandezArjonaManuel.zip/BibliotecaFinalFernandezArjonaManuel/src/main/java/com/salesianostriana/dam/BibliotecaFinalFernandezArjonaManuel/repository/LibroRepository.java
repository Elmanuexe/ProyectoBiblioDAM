package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Libro;


/*Implementa la interfaz JpaRepository para los métodos como findAll, getOne...*/
public interface LibroRepository extends JpaRepository <Libro, Long>{
	
	List <Libro> findByTituloIgnoreCase(String titulo);

}
