package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Libro {

	@Id
	@GeneratedValue
	private Long id;
	
	private String titulo;
	private String tituloOriginal;
	
	@ManyToOne
	private Autor autor;
	
	private int numPaginas;
	private String generoLiter;

	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fechaPubli;
	
	private String imagenPortada;

	public Libro(String titulo, String tituloOriginal, int numPaginas, String generoLiter,
			LocalDate fechaPubli, String imagenPortada) {
		super();
		this.titulo = titulo;
		this.tituloOriginal = tituloOriginal;
		this.numPaginas = numPaginas;
		this.generoLiter = generoLiter;
		this.fechaPubli = fechaPubli;
		this.imagenPortada = imagenPortada;
	}

}
