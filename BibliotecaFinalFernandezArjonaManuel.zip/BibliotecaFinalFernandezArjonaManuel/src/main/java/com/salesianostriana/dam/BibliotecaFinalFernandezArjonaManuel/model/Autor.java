package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data@AllArgsConstructor@NoArgsConstructor@Entity
public class Autor {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String nombre;
	private LocalDate fechaNacimiento;
	

	public Autor(String nombre, LocalDate fechaNacimiento, List<Libro> libros) {
		super();
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.libros = libros;
	}
	
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@OneToMany(mappedBy="autor", fetch = FetchType.EAGER)
	private List <Libro> libros;
	
	/**
	 * Método auxiliar para el tratamiento bidireccional de la asociación. Añade a un libro
	 * a la colección de libros de un autor, y asigna a dicho libro este autor como el suyo.
	 * @param l
	 */
	public void addLibro(Libro l) {
		this.libros.add(l);
		l.setAutor(this);	
	}
	
	/**
	 * Método auxiliar para el tratamiento bidireccional de la asociación. Elimina a un libro
	 * a la colección de libros de un autor, y desasigna a dicho libro el autor, dejandolo como nulo.
	 * @param l
	 */
	public void removeLibro(Libro l) {
		this.libros.remove(l);
		l.setAutor(null);
	}


}
