package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service;

import org.springframework.stereotype.Service;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Autor;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.repository.AutorRepository;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.base.BaseService;

@Service
public class AutorService extends BaseService<Autor, Long, AutorRepository>{

}
