package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Libro;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.repository.LibroRepository;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.base.BaseService;


/**
 * Como los servicios CRUD siempre suelen ser lo mismo, 
 * es buena idea crear un servicio base que haga esto, 
 * y dejar nuestro servicio "concreto" en otro sitio. 
 * Esta sería nuestra clase de servicio concreta (para las cosas propias de nuestra aplicación) que,
 * en este caso, al no tener una lógica de negocio más allá de los CRUD está vacía.
 * 
 * @author mfarjona
 *
 */

@Service
public class LibroService extends BaseService<Libro, Long, LibroRepository>{

	public List<Libro> buscarPorTitulo(String a){
		return this.repository.findByTituloIgnoreCase(a);
	}
}
