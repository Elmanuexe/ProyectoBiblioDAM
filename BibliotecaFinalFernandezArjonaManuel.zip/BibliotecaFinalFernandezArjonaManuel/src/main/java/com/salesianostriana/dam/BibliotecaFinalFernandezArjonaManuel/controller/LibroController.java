package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.DataMaster;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Libro;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.LibroService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class LibroController {

	@Autowired
	private LibroService libroService;
	
	@GetMapping({"/", "/libros"})
	public String todosLosAlumnos(Model model) {
		
		List<Libro> libros;
		libros = libroService.findAll();

		model.addAttribute("libros", libros);					

		return "index";
	}
	
	@GetMapping("/libro/{id}")
	public String unLibro(
			@PathVariable("id") Long id, Model model) {
		Libro a = libroService.findById(id);
		model.addAttribute("libro", a);
		
		return "detail";
	}
	
	@GetMapping("/libro/nuevo")
	public String muestraFormulario(Model model) {
		
		model.addAttribute("libro", new Libro());
		return "form";
	}
	
	@PostMapping("/libro/submit")
	public String guardarFormulario(@ModelAttribute("libro") Libro libro) {
		libroService.save(libro);
		//Rediregimos al controlador index para que muestre el listado de 
		//libros con el que se acaba de añadir  
		return "redirect:/";
	}
	
	@GetMapping("/editar/{id}")
	public String editarLibro(@PathVariable("id") Long id, Model model) {

		Libro libro = libroService.findById(id);
		
		String[] generos = new String[] { "Novela", "Cuento", "Epopeya", "Épica" };

		model.addAttribute("generos", generos);

		if (libro != null) {
			model.addAttribute("libro", libro);
			return "form";
		} else {
			return "redirect:/";
		}

	}
	
	@PostMapping("/editar/submit")
	public String procesarFormularioEdicion(@ModelAttribute("alumno") Libro a) {
		libroService.edit(a);
		return "redirect:/";//Volvemos a redirigir la listado a través del controller para pintar la lista actualizada con la modificación hecha
	}
	
	@GetMapping("/borrar/{id}")
	public String borrarLibro(@PathVariable("id") Long id, Model model) {

		Libro libro = libroService.findById(id);

		if (libro != null) {
			libroService.delete(libro);
		}

		return "redirect:/";

	}
	
	@ModelAttribute("generos")
		public List <String> generos(){
			return DataMaster.generos();
	}
}
