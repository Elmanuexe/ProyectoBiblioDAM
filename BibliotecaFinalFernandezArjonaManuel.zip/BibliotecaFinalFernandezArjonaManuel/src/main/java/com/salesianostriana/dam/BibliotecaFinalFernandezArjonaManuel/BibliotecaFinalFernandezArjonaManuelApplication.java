package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Autor;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Libro;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.AutorService;
import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.service.LibroService;

@SpringBootApplication
public class BibliotecaFinalFernandezArjonaManuelApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaFinalFernandezArjonaManuelApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(LibroService libroService, AutorService autorService) {
		return args -> {
			
			List <Libro> libros = new ArrayList <Libro>();
			//Creo los autores que voy a utilizar y los guardo
			Autor a1 = new Autor("Brandon Sanderson", LocalDate.of(1975, 12, 19), libros);
			Autor a2 = new Autor("Stephen King", LocalDate.of(1947, 9, 21), libros);
			Autor a3 = new Autor("Andrzej Sapkowski", LocalDate.of(1948, 7, 21), libros);
		
			autorService.save(a1);
			autorService.save(a2);
			autorService.save(a3);
			
			
			//Hacemos lo mismo con los libros de base
			List <Libro> brandonL = Arrays.asList(
					new Libro("Palabras radiantes", "Words of radiance", 1400, "Novela", LocalDate.of(2014, 3, 4), "https://www.penguinlibros.com/cl/51940/palabras-radiantes-el-archivo-de-las-tormentas-2.jpg"),
					new Libro("El imperio final", "The final empire", 700, "Novela", LocalDate.of(2006, 7, 17), "https://images-na.ssl-images-amazon.com/images/I/81G6v5bXYHL.jpg"),
					new Libro("Steelheart", "Steelheart", 336, "Epica", LocalDate.of(2013, 9, 24), "https://www.lacasadeel.net/wp-content/uploads/2014/06/Steelheart-brandon-sanderson-nova-ediciones-b.jpg")
					);
					
			List <Libro> kingL = Arrays.asList(
					new Libro("IT", "IT", 1503, "Novela", LocalDate.of(1986, 9, 15), "https://media1.popsugar-assets.com/files/thumbor/hq3K949yrbRYcY2Z1FhkJPvzNZE/fit-in/1024x1024/filters:format_auto-!!-:strip_icc-!!-/2017/10/19/865/n/1922283/548847f859e900fbda1c82.15106312_11c18fbb50b3abe089e5f519cc1988cb/i/Stephen-King.png")
					);
			
			List <Libro> andrzejL = Arrays.asList(
					new Libro("El último deseo", "Ostatnie życzenie", 286, "Cuento" ,LocalDate.of(1993, 5, 12), "https://pm1.narvii.com/7606/2386652aead316fc40af87172411bb8cdec0a23fr1-1000-1484v2_hq.jpg"),
					new Libro("La espada del destino", "Miecz przeznaczenia", 254, "Cuento", LocalDate.of(1992, 6, 25), "https://www.popularlibros.com/imagenes_grandes/9788493/978849328366.JPG")
					);
			
			for (Libro l : brandonL) {
				a1.addLibro(l);
				libroService.edit(l);
			}
			
			for (Libro l : kingL) {
				a2.addLibro(l);
				libroService.edit(l);
			}
			
			for (Libro l : andrzejL) {
				a3.addLibro(l);
				libroService.edit(l);
			}
			
		};
	}
}
