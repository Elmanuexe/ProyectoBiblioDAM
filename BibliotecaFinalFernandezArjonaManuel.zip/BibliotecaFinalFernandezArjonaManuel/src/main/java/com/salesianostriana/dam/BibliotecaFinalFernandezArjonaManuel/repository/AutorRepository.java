package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model.Autor;

public interface AutorRepository extends JpaRepository <Autor, Long>{

}
