package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model;

import java.util.List;

public class DataMaster {

	public static List <String> generos(){
		return List.of("Novela", "Cuento", "Epopeya", "Épica" );
	}
}
