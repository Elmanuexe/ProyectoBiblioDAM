package com.salesianostriana.dam.BibliotecaFinalFernandezArjonaManuel.model;

import java.util.List;

public class DataMaster {

	/*Se crea el metodo static para la correcta generacion del campo radiobutton del formulario*/
	public static List <String> generos(){
		return List.of("Novela", "Cuento", "Epopeya", "Épica" );
	}
}
